<?php 
date_default_timezone_set('Asia/Jakarta');
$nowtime = date("Y-m-d H:i:s");  
require 'koneksi/conn.php';
$komen = $_POST['komen_id'];
$postingan = $_POST['post_id'];
$isireply = $_POST['isireply'];
$user = 1;

function waktuAgo($waktu)
{
  $datetime1 = new DateTime(); // Today's Date/Time
  $datetime2 = new DateTime($waktu);
  $interval = $datetime1->diff($datetime2);
  $intervalHari = $interval->format('%d');
  $intervalJam = $interval->format('%h');
  $intervalMenit = $interval->format('%i');

  if ($intervalHari != '0') 
  {
    $hasil = $interval->format('%d Hari %h Jam %i Menit yang lalu') ;
  }
  elseif ($intervalHari == '0' AND $intervalJam != '0') 
  {
    $hasil = $interval->format('%h hours %i minutes ago') ;
  }
  elseif (($intervalHari == '0' AND $intervalJam == '0') AND $intervalMenit != '0') {
    $hasil = $interval->format('%i minutes ago') ;
  }
  return $hasil;
}

$komenr = $konek->query("INSERT INTO reply VALUES('','$user','$postingan','$komen','$nowtime','$isireply')");
// var_dump($komenr);

$sqlReply = "SELECT tbl_user_profile.nama_lengkap , berita.judul , reply.id_comment , reply.tgl_komen , reply.isi FROM reply
            LEFT JOIN tbl_user ON tbl_user.id = reply.id_user
            LEFT JOIN tbl_user_profile ON tbl_user_profile.email = tbl_user.email
            LEFT JOIN berita ON berita.id = reply.id_postingan
            WHERE id_comment = $komen AND id_postingan= $postingan AND reply.isi = '$isireply'
            ORDER BY reply.tgl_komen ASC";
// var_dump($sqlReply);
$queryreply = $konek->query($sqlReply); 
$replyan = $queryreply->fetch_assoc();
if ($queryreply == true) {
?>
<article id="comment-id-2" class="comment-item comment-reply">
	<a class="pull-left thumb-sm">
		<img src="images/avatar.jpg" class="img-rounded">
	</a>
	<section class="comment-body m-b">
		<header>
			<a href="#"><strong><?= $replyan['nama_lengkap'] ?></strong></a> 
			<span class="text-muted text-xs block m-t-xs">
			<?= $replyan['tgl_komen'] ?>
			</span>
		</header>
	<div class="m-t-sm"><?= $replyan['isi'] ?></div>
	</section>
</article>
<?php
}
?>