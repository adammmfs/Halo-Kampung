<?php  
$server = 'localhost';
$us = 'root';
$ps = '';
$db = 'hkampung_blog';

$konek = new mysqli($server,$us,$ps,$db);

// var_dump($konek);
?>