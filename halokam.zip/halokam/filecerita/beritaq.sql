/*
 Navicat Premium Data Transfer

 Source Server         : mysql
 Source Server Type    : MySQL
 Source Server Version : 100116
 Source Host           : localhost:3306
 Source Schema         : hkampung_blog

 Target Server Type    : MySQL
 Target Server Version : 100116
 File Encoding         : 65001

 Date: 25/11/2018 03:48:36
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for berita
-- ----------------------------
DROP TABLE IF EXISTS `berita`;
CREATE TABLE `berita`  (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `isi` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `post_by` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `post_tgl` date NULL DEFAULT NULL,
  `komen` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `foto` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of berita
-- ----------------------------
INSERT INTO `berita` VALUES (1, 'halo indonesia1', '<div>                          Go aheadâ€¦<b>lorem ipsum</b></div><div><b><br></b></div><div>dolor <i>si</i><br><b></b></div>', 'Admins', '2018-11-24', '', 'land2.jpg');
INSERT INTO `berita` VALUES (2, 'halo indonesia2', '<div>                          Go aheadâ€¦<b>lorem ipsum</b></div><div><b><br></b></div><div>dolor <i>si</i><br><b></b></div>', 'Admins', '2018-11-24', '', 'land1.jpg');
INSERT INTO `berita` VALUES (3, 'tesss', 'haloo<br>', 'Admin', '2018-11-23', '', NULL);

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `id_postingan` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `tgl_komen` timestamp(0) NULL DEFAULT NULL,
  `isi` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES (1, '1', '1', '2018-11-21 18:11:54', 'wahh sangat bagus kontennya');
INSERT INTO `comment` VALUES (2, '1', '2', '2018-11-23 18:11:59', 'kontennya bagus sekali, saya tidak menyangka');
INSERT INTO `comment` VALUES (3, '2', '1', '2018-11-24 18:22:46', 'saya sangat suka konten beginian');
INSERT INTO `comment` VALUES (4, '2', '2', '2018-11-20 19:45:18', 'saya suka artikel nya sangat menginspirasi');

-- ----------------------------
-- Table structure for reply
-- ----------------------------
DROP TABLE IF EXISTS `reply`;
CREATE TABLE `reply`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_user` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `id_postingan` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `id_comment` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `tgl_komen` timestamp(0) NULL DEFAULT NULL,
  `isi` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 19 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of reply
-- ----------------------------
INSERT INTO `reply` VALUES (1, '2', '1', '1', '2018-11-24 21:29:29', 'apa nya yang bagus? jelek gini');
INSERT INTO `reply` VALUES (2, '1', '1', '1', '2018-11-24 21:31:58', 'semuanya bagus');
INSERT INTO `reply` VALUES (3, '1', '1', '3', '0000-00-00 00:00:00', 'halllo');
INSERT INTO `reply` VALUES (4, '1', '1', '3', '0000-00-00 00:00:00', 'yessss');
INSERT INTO `reply` VALUES (5, '1', '1', '3', '2018-11-25 01:50:21', 'tessss');
INSERT INTO `reply` VALUES (6, '1', '1', '3', '2018-11-25 01:51:40', 'cek');
INSERT INTO `reply` VALUES (7, '1', '1', '3', '2018-11-25 01:53:03', 'tes again');
INSERT INTO `reply` VALUES (9, '1', '1', '3', '2018-11-25 02:01:54', 'tes 5 ');
INSERT INTO `reply` VALUES (10, '1', '1', '1', '2018-11-25 02:04:14', 'huh');
INSERT INTO `reply` VALUES (11, '1', '1', '1', '2018-11-25 02:04:16', 'huh');
INSERT INTO `reply` VALUES (12, '1', '1', '1', '2018-11-25 02:05:34', 'esss');
INSERT INTO `reply` VALUES (13, '1', '1', '1', '2018-11-25 02:06:54', 'tesss');
INSERT INTO `reply` VALUES (14, '1', '2', '2', '2018-11-25 02:16:52', 'bagus apanya?');
INSERT INTO `reply` VALUES (15, '1', '2', '4', '2018-11-25 02:17:12', 'guud lah kalau gitu');
INSERT INTO `reply` VALUES (16, '1', '2', '2', '2018-11-25 02:17:57', 'sepertinya benar');
INSERT INTO `reply` VALUES (17, '1', '2', '2', '2018-11-25 02:18:41', 'bisa pliss');
INSERT INTO `reply` VALUES (18, '1', '2', '4', '2018-11-25 02:18:50', 'bisa');

-- ----------------------------
-- Table structure for tbl_user
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user`;
CREATE TABLE `tbl_user`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `type` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `aktif` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_user
-- ----------------------------
INSERT INTO `tbl_user` VALUES (1, 'sharinnegan71@gmail.com', 'blabla', 'user', '1');
INSERT INTO `tbl_user` VALUES (2, 'f4rayy@gmail.com', 'blabla', 'user', '1');

-- ----------------------------
-- Table structure for tbl_user_profile
-- ----------------------------
DROP TABLE IF EXISTS `tbl_user_profile`;
CREATE TABLE `tbl_user_profile`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `nama_lengkap` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `alamat` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `hp` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `instansi` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `web` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `instagram` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  `foto_profile` varchar(255) CHARACTER SET latin1 COLLATE latin1_swedish_ci NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = latin1 COLLATE = latin1_swedish_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tbl_user_profile
-- ----------------------------
INSERT INTO `tbl_user_profile` VALUES (1, 'sharinnegan71@gmail.com', 'Ahmad Fauzan', 'jalan mongosidi', '082284829284', 'UINSU', 'blabla.com', 'blabla', '929.jpg');
INSERT INTO `tbl_user_profile` VALUES (2, 'f4rayy@gmail.com', 'Faray', 'jalan jalan', NULL, NULL, NULL, NULL, '86573.jpg');
INSERT INTO `tbl_user_profile` VALUES (3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

SET FOREIGN_KEY_CHECKS = 1;
