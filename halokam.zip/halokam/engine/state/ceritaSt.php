<?php

class ceritaSt
{
	private $tbl = "berita";
	private $st;

	function __construct()
	{
		$this -> st = new state;
	}

	public function getCerita()
	{
		$this -> st -> query(DB_SELECT."* FROM " . $this -> tbl);
   		return $this -> st -> queryAll();
	}

	public function getLast()
	{
		$this -> st -> query("SELECT * FROM berita ORDER BY post_tgl DESC LIMIT 3");
   		return $this -> st -> queryAll();
	}

	public function getComment()
	{
		$this-> st -> query("SELECT tbl_user.email, comment.tgl_komen, comment.isi, berita.judul, tbl_user_profile.foto_profile, tbl_user_profile.nama_lengkap FROM comment 
			LEFT JOIN tbl_user ON tbl_user.id = comment.id_user
			LEFT JOIN berita ON berita.id = comment.id_postingan
			LEFT JOIN tbl_user_profile ON tbl_user_profile.email = tbl_user.email
			ORDER BY comment.tgl_komen DESC");
		return $this -> st -> queryAll();
	}

	public function getSingle($id)
	{
		$this -> st -> query("SELECT * FROM berita WHERE id = '$id';");
		$this -> st -> queryAll();
	}
}