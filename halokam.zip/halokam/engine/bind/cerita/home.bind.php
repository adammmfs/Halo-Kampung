<!DOCTYPE html>
<html lang="en" class=" ">
<head>
  <meta charset="utf-8" />
  <title>Notebook | Web Application</title>
  <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="<?=STYLEBASE;?>css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="<?=STYLEBASE;?>css/animate.css" type="text/css" />
  <link rel="stylesheet" href="<?=STYLEBASE;?>css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="<?=STYLEBASE;?>css/font.css" type="text/css" />
  <link rel="stylesheet" href="<?=STYLEBASE;?>css/landing.css" type="text/css" />
  <link rel="stylesheet" href="<?=STYLEBASE;?>css/app.css" type="text/css" />
  <!--[if lt IE 9]>
    <script src="js/ie/html5shiv.js"></script>
    <script src="js/ie/respond.min.js"></script>
    <script src="js/ie/excanvas.js"></script>
  <![endif]-->
</head>
<body class="">
  	
  <!-- header -->
  <header id="header" class="navbar navbar-fixed-top bg-white box-shadow b-b b-light"  data-spy="affix" data-offset-top="1">
    <div class="container">
      <div class="navbar-header">        
        <a href="#" class="navbar-brand"><img src="images/logo.png" class="m-r-sm"><span class="text-muted">Notebook</span></a>
        <button class="btn btn-link visible-xs" type="button" data-toggle="collapse" data-target=".navbar-collapse">
          <i class="fa fa-bars"></i>
        </button>
      </div>
      <div class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li class="active">
            <a href="landing.html">Home</a>
          </li>
          <li>
            <a href="features.html">Features</a>
          </li>
          <li>
            <a href="price.html">Plans & Pricing</a>
          </li>
          <li>
            <a href="blog.html">Blog</a>
          </li>
          <li>
            <div class="m-t-sm"><a href="signin.html" class="btn btn-link btn-sm">Sign in</a> <a href="signup.html" class="btn btn-sm btn-success m-l"><strong>Sign up</strong></a></div>
          </li>
        </ul>
      </div>
    </div>
  </header>
  <!-- / header -->
	<section id="content">
	  <div class="bg-dark lt">
      <div class="container">
        <div class="m-b-lg m-t-lg">
          <h3 class="m-b-none">Blog</h3>
          <small class="text-muted">Just another blog</small>
        </div>
      </div>
    </div>
    <div class="bg-white b-b b-light">
      <div class="container"> 
        <ul class="breadcrumb no-border bg-empty m-b-none m-l-n-sm">
          <li><a href="landing.html">Home</a></li>
          <li class="active">Blog</li>
        </ul>
      </div>
    </div>
		<div class="container m-t-lg m-b-lg">
			<div class="row">
        <div class="col-sm-9">
          <div class="blog-post">
          <?php foreach ($berita as $beritaku): ?>		              	
            <div class="post-item">
            	<div class="post-media">
                <?php if ($beritaku['foto'] != null): ?>
            		<section class="panel bg-info dk m-b-none">
                  <div class="carousel auto slide panel-body" id="c-fade">
                      <img src="images/land/<?= $beritaku['foto'] ?>" width="100%" height="280px" style="padding: 0px">
                  </div>
                </section>
                <?php endif ?>  
            	</div>
              <div class="caption wrapper-lg">
                <h2 class="post-title"><a href="#"><?= ucfirst($beritaku['judul']) ?></a></h2>
                <div class="post-sum">
                  <?= $beritaku['isi'] ?>
                </div>
                <div class="line line-lg"></div>
                <div class="text-muted">
                  <i class="fa fa-user icon-muted"></i> by <a href="#" class="m-r-sm"><?= $beritaku['post_by'] ?></a>
                  <i class="fa fa-clock-o icon-muted"></i> <?php 
                  $waktu = date('M d,Y',strtotime($beritaku['post_tgl']));
                  echo $waktu;

                  ?>
                  <a href="#" class="m-l-sm"><i class="fa fa-comment-o icon-muted"></i> 2 comments</a>
                </div>
              </div>
            </div>
          <?php endforeach ?>
          </div>
          <div class="text-center m-t-lg m-b-lg">
            <ul class="pagination pagination-md">
              <li><a href="#"><i class="fa fa-chevron-left"></i></a></li>
              <li class="active"><a href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#">4</a></li>
              <li><a href="#">5</a></li>
              <li><a href="#"><i class="fa fa-chevron-right"></i></a></li>
            </ul>
          </div>
        </div>
          <div class="col-sm-3">
          <h5 class="font-semibold">Postingan Terbaru</h5>
          <div class="line line-dashed"></div>
          <div>
            <?php 
            foreach ($recent as $recentb) {
            ?>
            <article class="media">
              <a class="pull-left thumb thumb-wrapper m-t-xs">
                <?php if ($recentb['foto'] != null): ?>
                  <img src="images/land/<?= $recentb['foto'] ?>" style="height: 37.5px;width: 50px">
                <?php elseif ($recentb['foto'] == null OR $recentb['foto'] == ''): ?>
                  <img src="images/land/no_image.jpg"  style="height: 40.5px;width: 50px">
                <?php endif ?>
                
              </a>
              <div class="media-body">
                <a href="#" class="font-semibold"><?= $recentb['judul'] ?></a>
                <div class="text-xs block m-t-xs"><?php 
                  $wakturecent = date('M d,Y',strtotime($recentb['post_tgl']));
                  echo $wakturecent;
                  ?></div>
              </div>
            </article>
            <div class="line"></div>
            <?php } ?>
            <br/>
          <h5 class="font-semibold">Komentar Terbaru</h5>
          <div class="line line-dashed"></div>
          <div>
            <?php 
            foreach ($com as $commentz) {
            ?>
            <article class="media">
              <a class="pull-left thumb thumb-up m-t-xs" style="width: 40px;height: 35px;padding-right: 3px">
                <?php 
                if ($commentz['foto_profile'] != null): ?>
                  <img src="images/profile/<?= $commentz['foto_profile'] ?>" class="img-rounded" style="width: 100%;height: 100%">
                <?php elseif ($commentz['foto'] == null OR $commentz['foto'] == ''): ?>
                  <img src="images/images/default.jpg"  class="img-rounded">
                <?php endif ?>
              </a>
              <div class="comment-body">
                <header>
                <a href="#" class="font-semibold"><?= $commentz['nama_lengkap'] ?></a> on <a href="#" class="font-semibold"><?= $commentz['judul'] ?></a>
                <div class="text-xs block m-t-xs"><?php 
                  echo waktuAgo($commentz['tgl_komen'])
                  ?></div>
                <div class="m-t-sm"><?= $commentz['isi'] ?></div>
                </header>
              </div>
            </article>
            <div class="line"></div>
            <?php } ?>
          </div>
        </div>
        </div>
      </div>
    </div>
	</section>
  
  <!-- footer -->
  <footer id="footer">
    <div class="bg-primary text-center">
      <div class="container wrapper">
        <div class="m-t-xl m-b">
          For your faster and easier web development.
          <a href="http://themeforest.net/user/Flatfull/portfolio?ref=flatfull" target="_blank" class="btn btn-lg btn-dark b-white bg-empty m-sm">Download it</a>
          <a href="index.html" target="_blank" class="btn btn-lg btn-warning b-white bg-empty m-sm">Live Preview</a>
        </div>
      </div>
      <i class="fa fa-caret-down fa-4x text-primary m-b-n-lg block"></i>
    </div>
    <div class="bg-dark dker wrapper">
      <div class="container text-center m-t-lg">
        <div class="row m-t-xl m-b-xl">
          <div class="col-sm-4" data-ride="animated" data-animation="fadeInLeft" data-delay="300">
            <i class="fa fa-map-marker fa-3x icon-muted"></i>
            <h5 class="text-uc m-b m-t-lg">Find Us</h5>
            <p class="text-sm">23 soe Midlokls <br>
              120002 Loki — UNITED KINGDOM
             </p>
          </div>
          <div class="col-sm-4" data-ride="animated" data-animation="fadeInUp" data-delay="600">
            <i class="fa fa-envelope-o fa-3x icon-muted"></i>
            <h5 class="text-uc m-b m-t-lg">Mail Us</h5>
            <p class="text-sm"><a href="mailto:hey@example.com">info@example.com</a></p>
          </div>
          <div class="col-sm-4" data-ride="animated" data-animation="fadeInRight" data-delay="900">
            <i class="fa fa-globe fa-3x icon-muted"></i>
            <h5 class="text-uc m-b m-t-lg">Join Us</h5>
            <p class="text-sm">Send your resume to <br><a href="mailto:hey@example.com">recruit@example.com</a></p>
          </div>
        </div>
        <div class="m-t-xl m-b-xl">
          <p>
            <a href="#" class="btn btn-icon btn-rounded btn-facebook bg-empty m-sm"><i class="fa fa-facebook"></i></a>
            <a href="#" class="btn btn-icon btn-rounded btn-twitter bg-empty m-sm"><i class="fa fa-twitter"></i></a>
            <a href="#" class="btn btn-icon btn-rounded btn-gplus bg-empty m-sm"><i class="fa fa-google-plus"></i></a>
          </p>
          <p>
            <a href="#content" data-jump="true" class="btn btn-icon btn-rounded btn-dark b-dark bg-empty m-sm text-muted"><i class="fa fa-angle-up"></i></a>
          </p>
        </div>
      </div>
    </div>
  </footer>
  <!-- / footer -->  <script src="<?=STYLEBASE;?>js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="<?=STYLEBASE;?>js/bootstrap.js"></script>
  <!-- App -->
  <script src="<?=STYLEBASE;?>js/app.js"></script> 
  <script src="<?=STYLEBASE;?>js/slimscroll/jquery.slimscroll.min.js"></script>
  
  <script src="<?=STYLEBASE;?>js/appear/jquery.appear.js"></script>
  <script src="<?=STYLEBASE;?>js/scroll/smoothscroll.js"></script>
  <script src="<?=STYLEBASE;?>js/landing.js"></script>
  <script src="<?=STYLEBASE;?>js/app.plugin.js"></script>
</body>
</html>