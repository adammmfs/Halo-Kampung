	<section id="content">
	  <div class="bg-dark lt">
      <div class="container">
        <div class="m-b-lg m-t-lg">
          <h3 class="m-b-none">Cerita</h3>
          <small class="text-muted">Abadikan pengalamanmu saat melakukan kebaikan</small>
        </div>
      </div>
    </div>
    <div class="bg-white b-b b-light">
      <div class="container"> 
        <ul class="breadcrumb no-border bg-empty m-b-none m-l-n-sm">
          <li><a href="landing.html">Home</a></li>
          <li class="active">Blog</li>
        </ul>
      </div>
    </div>
		<div class="container m-t-lg m-b-lg">
			<div class="row">
        <div class="col-sm-9">
          <div class="blog-post">
          <?php foreach ($data['cerita'] as $ceritaku): ?>
            <div class="post-item">
            	<div class="post-media">
                <?php if ($ceritaku['foto'] != null): ?>
            		<section class="panel bg-info dk m-b-none">
                  <div class="carousel auto slide panel-body" id="c-fade">
                      <img src="<?=STYLEBASE;?>images/land/<?= $ceritaku['foto'] ?>" width="100%" height="280px" style="padding: 0px">
                  </div>
                </section>
                <?php endif ?>  
            	</div>
              <div class="caption wrapper-lg">
                <h2 class="post-title"><a href="#"><?= ucfirst($ceritaku['judul']) ?></a></h2>
                <div class="post-sum">
                  <?= $ceritaku['isi'] ?>
                </div>
                <div class="line line-lg"></div>
                <div class="text-muted">
                  <i class="fa fa-user icon-muted"></i> by <a href="#" class="m-r-sm"><?= $ceritaku['post_by'] ?></a>
                  <i class="fa fa-clock-o icon-muted"></i> <?php 
                  $waktu = date('M d,Y',strtotime($ceritaku['post_tgl']));
                  echo $waktu;

                  ?>
                  <a href="#" class="m-l-sm"><i class="fa fa-comment-o icon-muted"></i> 2 comments</a>
                </div>
              </div>
            </div>
          <?php endforeach ?>
          </div>
          <div class="text-center m-t-lg m-b-lg">
            <ul class="pagination pagination-md">
              <li><a href="#"><i class="fa fa-chevron-left"></i></a></li>
              <li class="active"><a href="#">1</a></li>
              <li><a href="#">2</a></li>
              <li><a href="#">3</a></li>
              <li><a href="#">4</a></li>
              <li><a href="#">5</a></li>
              <li><a href="#"><i class="fa fa-chevron-right"></i></a></li>
            </ul>
          </div>
        </div>