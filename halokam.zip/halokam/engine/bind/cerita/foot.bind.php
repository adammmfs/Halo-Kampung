<footer id="footer">
    <div class="bg-dark dker wrapper">
      <div class="container text-center m-t-lg">
        <div class="row m-t-xl m-b-xl">
          <!--
          <div class="col-sm-4" data-ride="animated" data-animation="fadeInLeft" data-delay="300">
            <i class="fa fa-map-marker fa-3x icon-info"></i>
            <h5 class="text-uc m-b m-t-lg">Find Us</h5>
            <p class="text-sm">23 soe Midlokls <br>
              120002 Loki — UNITED KINGDOM
             </p>
          </div>
          -->
          <div class="col-sm-4">
            <h5> <a href="#">Fitur</a></h5>
            <h5> <a href="#">Kebijakan Privasi</a></h5>
            <h5> <a href="#">Keamanan</a></h5>
          </div>
          <div class="col-sm-4">
            <h5> <a href="#">Kontak Kami</a></h5>
            <h5> <a href="#">Pengalaman</a></h5>
            <h5> <a href="#">Pengembang</a></h5>
            <h5> <a href="#">Bergabung Tim</a></h5>
          </div>
          <div class="col-sm-4">
            <h5> <a href="#">Beranda</a></h5>
            <h5> <a href="#">Telusuri</a></h5>
            <h5> <a href="#">Daftar</a></h5>
            <h5> <a href="#">Masuk</a></h5>
            <h5> <a href="#">Berita</a></h5>
          </div>
          
        </div>
        <div class="m-t-xl m-b-xl">
          <p>
            <a href="#" class="btn btn-icon btn-rounded btn-facebook bg-empty m-sm"><i class="fa fa-facebook"></i></a>
            <a href="#" class="btn btn-icon btn-rounded btn-twitter bg-empty m-sm"><i class="fa fa-twitter"></i></a>
            <a href="#" class="btn btn-icon btn-rounded btn-gplus bg-empty m-sm"><i class="fa fa-google-plus"></i></a>
          </p>
          <p>
            <a href="#content" data-jump="true" class="btn btn-icon btn-rounded btn-dark b-dark bg-empty m-sm text-muted"><i class="fa fa-angle-up"></i></a>
          </p>
        </div>
      </div>
    </div>
  </footer>
  <!-- / footer -->  <script src="<?=STYLEBASE;?>js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="<?=STYLEBASE;?>js/bootstrap.js"></script>
  <!-- App -->
  <script src="<?=STYLEBASE;?>js/app.js"></script> 
  <script src="<?=STYLEBASE;?>js/slimscroll/jquery.slimscroll.min.js"></script>
  
  <script src="<?=STYLEBASE;?>js/appear/jquery.appear.js"></script>
  <script src="<?=STYLEBASE;?>js/scroll/smoothscroll.js"></script>
  <script src="<?=STYLEBASE;?>js/landing.js"></script>
  <script src="<?=STYLEBASE;?>js/app.plugin.js"></script>
</body>
</html>