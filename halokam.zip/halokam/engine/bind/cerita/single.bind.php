  <!-- / header -->
	<section id="content">
	  <div class="bg-dark lt">
      <div class="container">
        <div class="m-b-lg m-t-lg">
          <h3 class="m-b-none">Blog</h3>
          <small class="text-muted">Just another blog</small>
        </div>
      </div>
    </div>
    <div class="bg-white b-b b-light">
      <div class="container"> 
        <ul class="breadcrumb no-border bg-empty m-b-none m-l-n-sm">
          <li><a href="landing.html">Home</a></li>
          <li class="active">Blog</li>
        </ul>
      </div>
    </div>
    <?php
    var_dump($data['ceritaSingle']['id']);
    ?>
		<div class="container m-t-lg m-b-lg">
			<div class="row">
        <div class="col-sm-9">
          <div class="blog-post">              	
            <div class="post-item">
            	<div class="post-media">
                <?php if ($data['ceritaSingle']['foto'] != null): ?>
            		<section class="panel bg-info dk m-b-none">
                  <div class="carousel auto slide panel-body" id="c-fade">
                      <img src="images/land/<?= $data['ceritaSingle']['foto'] ?>" width="100%" height="280px" style="padding: 0px">
                  </div>
                </section>
                <?php endif ?>  
            	</div>
              <div class="caption wrapper-lg">
                <h2 class="post-title"><a href="#"><?= ucfirst($data['ceritaSingle']['judul']) ?></a></h2>
                <div class="post-sum">
                  <?= $data['ceritaSingle']['isi'] ?>
                </div>
                <div class="line line-lg"></div>
                <div class="text-muted">
                  <i class="fa fa-user icon-muted"></i> by <a href="#" class="m-r-sm"><?= $data['ceritaSingle']['post_by'] ?></a>
                  <i class="fa fa-clock-o icon-muted"></i> <?php 
                  $waktu = date('M d,Y',strtotime($data['ceritaSingle']['post_tgl']));
                  echo $waktu;

                  ?>
                  <a href="#" class="m-l-sm"><i class="fa fa-comment-o icon-muted"></i> 2 comments</a>
                </div>
              </div>
            </div>
          </div>
          <h4 class="m-t-lg m-b">3 Comments</h4>
          <section class="comment-list block">
            <?php foreach ($komenIni as $komenan): ?>
            <article id="comment-id-1" class="comment-item">
              <a class="pull-left thumb-sm">
                <img src="images/avatar.jpg" class="img-rounded">
              </a>
              <section class="comment-body m-b">
                <header>
                  <a href="#"><strong><?= $komenan['nama_lengkap'] ?></strong></a>
                  <label class="label bg-info m-l-xs">Editor</label> 
                  <span class="text-muted text-xs block m-t-xs">
                    <?= waktuAgo($komenan['tgl_komen']) ?>
                  </span>
                </header>
                <div class="m-t-sm"><?= $komenan['isi'] ?></div>
                <div class="m-t-sm" style="margin-top: 1px"><a href="#" onclick="munculKotak(<?= $komenan['id'] ?>)"><small>reply</small></a></div>
              </section>
            </article>
            <article id="replykomen-<?= $komenan['id'] ?>" class="comment-item comment-reply" style="display: none;">
              <a class="pull-left thumb-sm">
                <img src="images/avatar.jpg" class="img-rounded">
              </a>
              <section class="comment-body m-b">
                <header>
                  <a href="#"><strong>Nama</strong></a> 
                </header>
                <div class="m-t-sm">
                <div class="row">
                <div class="col-sm-9">
                <input class="form-control input-sm" id="replyku-<?= $komenan['id'] ?>" type="text" name="replyku" placeholder="Type your reply">
                </div>
                <div class="col-sm-2">
                  <span id="load-<?= $komenan['id']?>"></span>
                  <button type="button" onclick="kirimreply(<?= $komenan['id'] ?>)" class="btn btn-primary btn-sm">button</button></div>
                </div>
                </div>
              </section>
            </article>
            <!-- .comment-reply -->
            <?php
            $idkom = $komenan['id'];
            // var_dump($idkom);
            $sqlReply = "SELECT tbl_user_profile.nama_lengkap , berita.judul , reply.id_comment , reply.tgl_komen , reply.isi FROM reply
            LEFT JOIN tbl_user ON tbl_user.id = reply.id_user
            LEFT JOIN tbl_user_profile ON tbl_user_profile.email = tbl_user.email
            LEFT JOIN berita ON berita.id = reply.id_postingan
            WHERE id_comment = $idkom AND id_postingan= $idnews
            ORDER BY reply.tgl_komen ASC";

            $replyIni = $konek->query($sqlReply);
            // var_dump($sqlReply);

            foreach ($replyIni as $replyan){ ?>
            <article id="comment-id-2" class="comment-item comment-reply">
              <a class="pull-left thumb-sm">
                <img src="images/avatar.jpg" class="img-rounded">
              </a>
              <section class="comment-body m-b">
                <header>
                  <a href="#"><strong><?= $replyan['nama_lengkap'] ?></strong></a> 
                  <span class="text-muted text-xs block m-t-xs">
                    <?= waktuAgo($replyan['tgl_komen']) ?>
                  </span>
                </header>
                <div class="m-t-sm"><?= $replyan['isi'] ?></div>
              </section>
            </article>
            <?php } ?>
            <?php endforeach ?>
          </section>
          <h4 class="m-t-lg m-b">Leave a comment</h4>
          <form>
            <div class="form-group pull-in clearfix">
              <div class="col-sm-6">
                <label>Your name</label>
                <input type="text" class="form-control" placeholder="Name">
              </div>
              <div class="col-sm-6">
                <label >Email</label>
                <input type="email" class="form-control" placeholder="Enter email">
              </div>
            </div>
            <div class="form-group">
              <label>Comment</label>
              <textarea class="form-control" rows="5" placeholder="Type your comment"></textarea>
            </div>
            <div class="form-group">
              <button type="submit" class="btn btn-success">Submit comment</button>
            </div>
          </form>
        </div>
          <div class="col-sm-3">
          <h5 class="font-semibold">Postingan Terbaru</h5>
          <div class="line line-dashed"></div>
          <div>
            <?php 
            foreach ($recent as $recentb) {
            ?>
            <article class="media">
              <a class="pull-left thumb thumb-wrapper m-t-xs">
                <?php if ($recentb['foto'] != null): ?>
                  <img src="images/land/<?= $recentb['foto'] ?>" style="height: 37.5px;width: 50px">
                <?php elseif ($recentb['foto'] == null OR $recentb['foto'] == ''): ?>
                  <img src="images/land/no_image.jpg"  style="height: 40.5px;width: 50px">
                <?php endif ?>
                
              </a>
              <div class="media-body">
                <a href="#" class="font-semibold"><?= $recentb['judul'] ?></a>
                <div class="text-xs block m-t-xs"><?php 
                  $wakturecent = date('M d,Y',strtotime($recentb['post_tgl']));
                  echo $wakturecent;
                  ?></div>
              </div>
            </article>
            <div class="line"></div>
            <?php } ?>
            <br/>
          <h5 class="font-semibold">Komentar Terbaru</h5>
          <div class="line line-dashed"></div>
          <div>
            <?php 
            foreach ($com as $commentz) {
            ?>
            <article class="media">
              <a class="pull-left thumb thumb-up m-t-xs" style="width: 40px;height: 35px;padding-right: 3px">
                <?php 
                if ($commentz['foto_profile'] != null): ?>
                  <img src="images/profile/<?= $commentz['foto_profile'] ?>" class="img-rounded" style="width: 100%;height: 100%">
                <?php elseif ($commentz['foto'] == null OR $commentz['foto'] == ''): ?>
                  <img src="images/images/default.jpg"  class="img-rounded">
                <?php endif ?>
              </a>
              <div class="comment-body">
                <header>
                <a href="#" class="font-semibold"><?= $commentz['nama_lengkap'] ?></a> on <a href="#" class="font-semibold"><?= $commentz['judul'] ?></a>
                <div class="text-xs block m-t-xs"><?php 
                  echo waktuAgo($commentz['tgl_komen'])
                  ?></div>
                <div class="m-t-sm"><?= $commentz['isi'] ?></div>
                </header>
              </div>
            </article>
            <div class="line"></div>
            <?php } ?>
          </div>
        </div>
        </div>
      </div>
    </div>
	</section>
  
  <!-- footer -->
  <footer id="footer">
    <div class="bg-primary text-center">
      <div class="container wrapper">
        <div class="m-t-xl m-b">
          For your faster and easier web development.
          <a href="http://themeforest.net/user/Flatfull/portfolio?ref=flatfull" target="_blank" class="btn btn-lg btn-dark b-white bg-empty m-sm">Download it</a>
          <a href="index.html" target="_blank" class="btn btn-lg btn-warning b-white bg-empty m-sm">Live Preview</a>
        </div>
      </div>
      <i class="fa fa-caret-down fa-4x text-primary m-b-n-lg block"></i>
    </div>
    <div class="bg-dark dker wrapper">
      <div class="container text-center m-t-lg">
        <div class="row m-t-xl m-b-xl">
          <div class="col-sm-4" data-ride="animated" data-animation="fadeInLeft" data-delay="300">
            <i class="fa fa-map-marker fa-3x icon-muted"></i>
            <h5 class="text-uc m-b m-t-lg">Find Us</h5>
            <p class="text-sm">23 soe Midlokls <br>
              120002 Loki — UNITED KINGDOM
             </p>
          </div>
          <div class="col-sm-4" data-ride="animated" data-animation="fadeInUp" data-delay="600">
            <i class="fa fa-envelope-o fa-3x icon-muted"></i>
            <h5 class="text-uc m-b m-t-lg">Mail Us</h5>
            <p class="text-sm"><a href="mailto:hey@example.com">info@example.com</a></p>
          </div>
          <div class="col-sm-4" data-ride="animated" data-animation="fadeInRight" data-delay="900">
            <i class="fa fa-globe fa-3x icon-muted"></i>
            <h5 class="text-uc m-b m-t-lg">Join Us</h5>
            <p class="text-sm">Send your resume to <br><a href="mailto:hey@example.com">recruit@example.com</a></p>
          </div>
        </div>
        <div class="m-t-xl m-b-xl">
          <p>
            <a href="#" class="btn btn-icon btn-rounded btn-facebook bg-empty m-sm"><i class="fa fa-facebook"></i></a>
            <a href="#" class="btn btn-icon btn-rounded btn-twitter bg-empty m-sm"><i class="fa fa-twitter"></i></a>
            <a href="#" class="btn btn-icon btn-rounded btn-gplus bg-empty m-sm"><i class="fa fa-google-plus"></i></a>
          </p>
          <p>
            <a href="#content" data-jump="true" class="btn btn-icon btn-rounded btn-dark b-dark bg-empty m-sm text-muted"><i class="fa fa-angle-up"></i></a>
          </p>
        </div>
      </div>
    </div>
  </footer>
  <!-- / footer -->  <script src="js/jquery.min.js"></script>
  <!-- Bootstrap -->
  <script src="js/bootstrap.js"></script>
  <!-- App -->
  <script src="js/app.js"></script> 
  <script src="js/slimscroll/jquery.slimscroll.min.js"></script>
  
  <script src="js/appear/jquery.appear.js"></script>
  <script src="js/scroll/smoothscroll.js"></script>
  <script src="js/landing.js"></script>
  <script src="js/app.plugin.js"></script>
</body>
</html>
<script type="text/javascript">
  function munculKotak($ke) {
    var replykomen = document.getElementById('replykomen-'+$ke);
    if (replykomen.style.display === "none") {
        replykomen.style.display = "block";
    } else {
        replykomen.style.display = "none";
    }
  }
</script>
<script type="text/javascript">
  function timeRefresh(timeoutPeriod) {
            setTimeout("location.reload(true);", timeoutPeriod);
        }
  function kirimreply(kode) {
    var replyku = document.getElementById('replyku-'+kode);
    var postid = <?= $idnews ?>;
    var isireply = replyku.value;
    $.ajax({
        type: "POST",
        url: "ajaxkomen.php",
        data: {
            komen_id:kode,
            isireply:isireply,
            post_id:postid
        },
        success: function(data){
            $("#load-"+kode).html("<i class='fa fa-spin fa-refresh'></i>");
            timeRefresh(2000);
        }
        });
  }
</script>