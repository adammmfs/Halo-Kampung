<!DOCTYPE html>
<html lang="en" class=" ">
<head>
  <meta charset="utf-8" />
  <title>Halo Kampung</title>
  <meta name="description" content="app, web app, responsive, admin dashboard, admin, flat, flat ui, ui kit, off screen nav" />
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" /> 
  <link rel="stylesheet" href="<?=STYLEBASE; ?>css/bootstrap.css" type="text/css" />
  <link rel="stylesheet" href="<?=STYLEBASE; ?>css/animate.css" type="text/css" />
  <link rel="stylesheet" href="<?=STYLEBASE; ?>css/font-awesome.min.css" type="text/css" />
  <link rel="stylesheet" href="<?=STYLEBASE; ?>css/font.css" type="text/css" />
  <link rel="stylesheet" href="<?=STYLEBASE; ?>css/landing.css" type="text/css" />
  <link rel="stylesheet" href="<?=STYLEBASE; ?>css/app.css" type="text/css" />
  <!--[if lt IE 9]>
    <script src="js/ie/html5shiv.js"></script>
    <script src="js/ie/respond.min.js"></script>
    <script src="js/ie/excanvas.js"></script>
  <![endif]-->
</head>
<body class="">
    
  <!-- header -->
  <header id="header" class="navbar navbar-fixed-top bg-white box-shadow b-b b-light"  data-spy="affix" data-offset-top="1">
    <div class="container">
      <div class="navbar-header">        
        <a href="#" class="navbar-brand"><img src="<?=STYLEBASE;?>images/logo.png" class="m-r-sm"><span class="text-muted">Halo</span><span class="text-info ">Kampung</span></a>
        <button class="btn btn-link visible-xs" type="button" data-toggle="collapse" data-target=".navbar-collapse">
          <i class="fa fa-bars"></i>
        </button>
      </div>
      <div class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li class="active">
            <a href="landing.html">Beranda</a>
          </li>
          <li>
            <a href="features.html">Telusuri</a>
          </li>
          <li>
            <a href="price.html">Cerita</a>
          </li>
          <li>
            <div class="m-t-sm"><a href="signin.html" class="btn btn-link btn-sm">Daftar</a> <a href="signup.html" class="btn btn-info btn-success m-l"><strong>Masuk</strong></a></div>
          </li>
        </ul>
      </div>
    </div>
  </header>