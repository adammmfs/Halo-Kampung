
        <?php
        function waktuAgo($waktu)
{
  $datetime1 = new DateTime(); // Today's Date/Time
  $datetime2 = new DateTime($waktu);
  $interval = $datetime1->diff($datetime2);
  $intervalHari = $interval->format('%d');
  $intervalJam = $interval->format('%h');
  $intervalMenit = $interval->format('%i');

  if ($intervalHari != '0') 
  {
    $hasil = $interval->format('%d Hari %h Jam %i Menit yang lalu') ;
  }
  elseif ($intervalHari == '0' AND $intervalJam != '0') 
  {
    $hasil = $interval->format('%h hours %i minutes ago') ;
  }
  elseif (($intervalHari == '0' AND $intervalJam == '0') AND $intervalMenit != '0') {
    $hasil = $interval->format('%i minutes ago') ;
  }
  return $hasil;
}?>

        <div class="col-sm-3">
          <h5 class="font-semibold">Postingan Terbaru</h5>
          <div class="line line-dashed"></div>
          <div>
            <?php 
            foreach ($data['cerita_last'] as $recentb) {
            ?>
            <article class="media">
              <a class="pull-left thumb thumb-wrapper m-t-xs">
                <?php if ($recentb['foto'] != null): ?>
                  <img src="<?=STYLEBASE;?>images/land/<?= $recentb['foto'] ?>" style="height: 37.5px;width: 50px">
                <?php elseif ($recentb['foto'] == null OR $recentb['foto'] == ''): ?>
                  <img src="images/land/no_image.jpg"  style="height: 40.5px;width: 50px">
                <?php endif ?>
                
              </a>
              <div class="media-body">
                <a href="#" class="font-semibold"><?= $recentb['judul'] ?></a>
                <div class="text-xs block m-t-xs"><?php 
                  $wakturecent = date('M d,Y',strtotime($recentb['post_tgl']));
                  echo $wakturecent;
                  ?></div>
              </div>
            </article>
            <div class="line"></div>
            <?php } ?>
            <br/>
          <h5 class="font-semibold">Komentar Terbaru</h5>
          <div class="line line-dashed"></div>
          <div>
            <?php 
            foreach ($data['comment'] as $commentz) {
            ?>
            <article class="media">
              <a class="pull-left thumb thumb-up m-t-xs" style="width: 40px;height: 35px;padding-right: 3px">
                <?php 
                if ($commentz['foto_profile'] != null): ?>
                  <img src="images/profile/<?= $commentz['foto_profile'] ?>" class="img-rounded" style="width: 100%;height: 100%">
                <?php elseif ($commentz['foto'] == null OR $commentz['foto'] == ''): ?>
                  <img src="images/images/default.jpg"  class="img-rounded">
                <?php endif ?>
              </a>
              <div class="comment-body">
                <header>
                <a href="#" class="font-semibold"><?= $commentz['nama_lengkap'] ?></a> on <a href="#" class="font-semibold"><?= $commentz['judul'] ?></a>
                <div class="text-xs block m-t-xs"><?php 
                  echo waktuAgo($commentz['tgl_komen'])
                  ?></div>
                <div class="m-t-sm"><?= $commentz['isi'] ?></div>
                </header>
              </div>
            </article>
            <div class="line"></div>
            <?php } ?>
          </div>
        </div>
        </div>
      </div>
    </div>
  </section>  