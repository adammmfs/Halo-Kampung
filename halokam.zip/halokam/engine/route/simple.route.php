<?php


class Simple extends Route
{
	
	public function index()
	{
		$this->bind('/home/home');
	}

	public function FunctionName()
	{
		# code...
	}
}
