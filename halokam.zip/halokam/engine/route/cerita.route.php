<?php
/**
 * 
 */
class Cerita extends Route
{
	
	public function index(){
	$this->bind('/cerita/head');
	$data['cerita'] = $this -> state('ceritaSt') -> getCerita();
	$data['cerita_last'] = $this -> state('ceritaSt') -> getLast();
	$data['comment']= $this->state('ceritaSt') -> getComment();
	$this->bind('/cerita/isi',$data);
	$this->bind('/cerita/samping',$data);
	$this->bind('/cerita/foot');	
	}

	public function single(){
		$this->bind('/cerita/head');
		$id = $this -> inputGet('id');
		$data['ceritaSingle'] = $this ->  state('ceritaSt') -> getSingle($id);
		$this->bind('/cerita/single',$data);
		
		//$this->bind('/cerita/foot');
	}


	
}