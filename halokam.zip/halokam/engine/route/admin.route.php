<?php

class Admin extends Route
{
	
	public function index()
	{
		echo "halaman admin";
	}
}